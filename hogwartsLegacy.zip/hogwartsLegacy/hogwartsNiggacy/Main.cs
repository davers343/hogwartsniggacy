﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hogwartsNiggacy
{
     class Program
    {
        static void Main(string[] args)
        {
            Avventura c = new Avventura();
            c.Start();
        }
    }
}
