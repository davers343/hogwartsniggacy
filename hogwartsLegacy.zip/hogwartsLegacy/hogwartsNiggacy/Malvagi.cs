﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hogwartsNiggacy
{
     class Malvagi: Personaggio
    {
        public string casataA { get; set; }
        public int forza1 { get; set; }
        public Malvagi(string casata, string nome, int esperienzaCombattimento, int hp) : base(nome, esperienzaCombattimento, hp)
        {
            casataA = casata;
            forza1 = CalcolaForzaCombattimento(esperienzaCombattimento, casataA);
        }
        public override int CalcolaForzaCombattimento(int esp, string casataAppartenenza)
        {
            int forzaBase = 0;

            switch (casataAppartenenza)
            {
                case "mago mangiamorte":
                    forzaBase = 10;
                    return forzaBase + 6 * esperienzaCombattimento;

                case "dissennatore":
                    forzaBase = 10;
                    return forzaBase + 5 * esperienzaCombattimento;

                case "lupo mannaro":
                    forzaBase = 8;
                    return forzaBase + 2 * esperienzaCombattimento;

                case "gigante":
                    forzaBase = 10;
                    return forzaBase + 2 * esperienzaCombattimento;

                case "maestro":
                    forzaBase = 12;
                    return forzaBase + 7 * esperienzaCombattimento;
                default:
                    // default fa ritornare 0 se la casata inserita non esiste
                    return forzaBase;
            }
        }
    }
}
