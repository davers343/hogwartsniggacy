﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hogwartsNiggacy
{
     class MagoMaster: Personaggio
    {
        public int energiaVitale { get; set; }
        public int forza { get; set; }
        

        public MagoMaster(string nome, int esperienzaCombattimento, int hp): base(nome, esperienzaCombattimento, hp)
        {
            
            forza = CalcolaForzaCombattimento(esperienzaCombattimento, "maestro");
            energiaVitale = CalcolaEnergiaVitale(esperienzaCombattimento);
        }

        public override int CalcolaForzaCombattimento(int esp, string casataAppartenenza)
        {
            
          return   50 * esp + 50 * energiaVitale;
        }
        public int CalcolaEnergiaVitale(int esperienza)
        {
            switch (esperienza)
            {
                case 1:
                    return 1* esperienza;
                case 2:
                    return 2 * esperienza;
                case 3:
                    return 3 * esperienza;
                case 4:
                    return 4 * esperienza;
                case 5:
                    return 5 * esperienza;
                case 6:
                    return 6 * esperienza;
                case 7:
                    return 7 * esperienza;
                case 8:
                    return 8 * esperienza;
                case 9:
                    return 9 * esperienza;
                case 10:
                    return 10 * esperienza;
                default:
                    if (esperienza > 10)
                    {
                        return esperienza * esperienza;
                    }
                    else return 0;
                    
            }
        }
        
    }
}
