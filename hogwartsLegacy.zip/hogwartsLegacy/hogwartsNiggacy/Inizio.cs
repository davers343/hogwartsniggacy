﻿using System;
using System.Reflection.Emit;
using System.Security.Cryptography;

namespace hogwartsNiggacy
{
    class Avventura
    {
        
        public void Start()
        {
            
            string schieramento;
            Console.WriteLine("Benvenuto in Hogwarts Legacy\n");
            Thread.Sleep(1000);
            do
            {
                Console.WriteLine("Creazione personaggio\nScegli se unirti alle forze del Bene o del Male: \ndigita : Bene\ndigita : Male");
                schieramento = Console.ReadLine();
            } while (schieramento != "Bene" && schieramento != "Male");

            switch (schieramento)
            {
                case "Bene":
                    Random r= new Random();
                    Console.WriteLine("Ti sei unito alle forze del Bene! \nCombatterai contro le forze del Male \nLa tua missione è eliminare il più grande Terrore del mondo : Tu-Sai-Chi ");
                    Thread.Sleep(200);
                    Console.WriteLine("Prima di tutto , come ti chiami ? ");
                    string nome = Console.ReadLine();
                    MagoMaster mainPg = new MagoMaster(nome, 7, 20); ////main 
                    Personaggio[] alleati = new Personaggio[2]
                    {
                       
                        new Buoni("grifondoro","Harry Potter", r.Next(1,10), 10 ),  
                        new Buoni("tassorosso", "Cedric Diggory",r.Next(1,10), 10)
                    };
                    Personaggio[] nemici = new Personaggio[4]
                   {

                        new Malvagi("gigante","Nagini", r.Next(1,10), 5 ),
                        new Malvagi("mago mangiamorte", "Lucius Malfoy",r.Next(1,10), 6),
                        new Malvagi("mago mangiamorte","Draco Malfoy", r.Next(1,10), 7 ),
                        new Malvagi("dissennatore", "Dissennatore",r.Next(1,10), 8), 
                          
                   };
                    //////creazione del boss
                    MagoMaster boss= new MagoMaster("Lord Voldemort", 6, 20);   ////boss
                    Console.WriteLine("\nBene {0}!\nEcco la lista dei tuoi alleati: ", mainPg.nome);
                    Thread.Sleep(200);
                    foreach (Buoni buono in alleati)
                    {
                        Console.WriteLine("\nAlleato: \nnome: {0}\ncasata: {1}\nesperienza di combattimento: {2}\nforza di combattimento: {3}",buono.nome, buono.casataA, buono.esperienzaCombattimento, buono.forza1 );
                        Thread.Sleep(300);
                    }
                    Thread.Sleep(500);
                    Console.WriteLine("\nPremi un tasto per continuare...");
                    Console.ReadKey();
                    Console.WriteLine("\nEcco la lista dei tuoi nemici: ");
                    Thread.Sleep(500);
                    foreach (Malvagi cattivi in nemici)
                    {
                        Console.WriteLine("\nNemico: \nnome: {0}\nappartenenza: {1}\nesperienza di combattimento: {2}\nforza di combattimento: {3}", cattivi.nome, cattivi.casataA, cattivi.esperienzaCombattimento, cattivi.forza1);
                        Thread.Sleep(300);
                    }
                    Thread.Sleep(300);
                    Console.WriteLine("\nPremi un tasto per continuare... ");
                    Console.ReadKey();
                    inizio();
                    ConsoleColor colorePredefinito2 = Console.ForegroundColor;
                    Console.ForegroundColor = ConsoleColor.DarkGreen;
                    Console.Write("V");
                    Thread.Sleep(400);
                    Console.Write("o");
                    Thread.Sleep(400);
                    Console.Write("l");
                    Thread.Sleep(400);
                    Console.Write("d");
                    Thread.Sleep(400);
                    Console.Write("e");
                    Thread.Sleep(400);
                    Console.Write("m");
                    Thread.Sleep(400);
                    Console.Write("o");
                    Thread.Sleep(400);
                    Console.Write("r");
                    Thread.Sleep(400);
                    Console.Write("t");
                    Thread.Sleep(400);
                    Console.ForegroundColor = colorePredefinito2;

                    Console.WriteLine("\nPremi un tasto per cominciare a combattere contro le forze del Male...\n");
                    Console.ReadKey();

                    int forzatotPg2 = 0;
                    foreach (Buoni alleato in alleati)
                    {
                        forzatotPg2 = mainPg.forza + alleato.forza1;  ///somma delle forze comb di ogni personaggio buono
                    }
                    int forzatotN2 = 0;
                    foreach (Malvagi nemico in nemici)
                    {
                        forzatotPg2 = mainPg.forza + nemico.forza1;  ///somma delle forze comb di ogni personaggio cattivo
                    }
                    if (forzatotPg2 > forzatotN2)
                    {
                        mainPg.energiaVitale += 10;
                        Console.WriteLine("La tua forza combattiva totale è maggiore di quella dei tuoi nemici\nOttieni +10 energia vitale ");
                    }
                    if (forzatotPg2 < forzatotN2)
                    {
                        boss.energiaVitale += 8;
                        Console.WriteLine("La tua forza combattiva totale è minore di quella dei tuoi nemici\nIl nemico ottiene +8 energia vitale ");
                    }
                    if (forzatotPg2 == forzatotN2)
                    {
                        boss.energiaVitale += 5;
                        mainPg.energiaVitale += 5;
                        Console.WriteLine("La tua forza combattiva totale è uguale a quella dei tuoi nemici\nEntrambi ottenete +5 energia vitale ");
                    }
                    Random at = new Random();
                    while (mainPg.energiaVitale > 0 && boss.energiaVitale > 0)
                    {
                        Console.WriteLine("\nEnergia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg.nome, mainPg.energiaVitale, boss.nome, boss.energiaVitale);
                        int calcolaTurno = at.Next(1, 3);
                        //// il turno è calcolato in base alla forza totale dei due personaggi(master+ alleati)
                        if (calcolaTurno == 1)
                        {
                            lancioDadi();
                            Console.WriteLine("\nTuo turno: ");
                            foreach (Buoni alleato in alleati)
                            {
                                ///attacco dei tuoi alleati
                                int attacco = at.Next(1, 5);
                                boss.energiaVitale -= attacco;
                                Console.WriteLine("{0} infligge {1} di danni a {2}", alleato.nome, attacco, boss.nome);
                                Console.WriteLine("Energia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg.nome, mainPg.energiaVitale, boss.nome, boss.energiaVitale);
                            }
                            ///tuo attacco
                            int attaccoPrincipale = at.Next(2, 10);
                            boss.energiaVitale -= attaccoPrincipale;
                            Console.WriteLine("{0} infligge {1} di danni a {2}", mainPg.nome, attaccoPrincipale, boss.nome);
                            Console.WriteLine("Energia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg.nome, mainPg.energiaVitale, boss.nome, boss.energiaVitale);
                            if (boss.energiaVitale <= 0)
                            {
                                bacchetta2(mainPg);
                                vittoria();
                                break;
                            }
                            Console.WriteLine("Premi per continuare...");
                            Console.ReadKey();
                            Console.WriteLine("\nTurno del nemico: ");
                            foreach (Malvagi nemico in nemici)
                            {
                                ///attacco dei alleati del nemico
                                int attacco = at.Next(1, 3);
                                mainPg.energiaVitale -= attacco;
                                Console.WriteLine("{0} infligge {1} di danni a {2}", nemico.nome, attacco, mainPg.nome);
                                Console.WriteLine("Energia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg.nome, mainPg.energiaVitale, boss.nome, boss.energiaVitale);

                            }
                            /// attacco del nemico

                            int attaccoNemico = at.Next(2, 10);
                            mainPg.energiaVitale -= attaccoNemico;
                            Console.WriteLine("{0} infligge {1} di danni a {2}", boss.nome, attaccoNemico, mainPg.nome);
                            Console.WriteLine("Energia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg.nome, mainPg.energiaVitale, boss.nome, boss.energiaVitale);

                            if (mainPg.energiaVitale <= 0)
                            {
                                bacchetta(boss);
                                sconfitta();
                                break;
                            }
                        }
                        if (calcolaTurno == 2)
                        {
                            lancioDadi();
                            Console.WriteLine("\nTurno del nemico: ");
                            foreach (Malvagi nemico in nemici)
                            {
                                ///attacco dei alleati del nemico
                                int attacco = at.Next(1, 3);
                                mainPg.energiaVitale -= attacco;
                                Console.WriteLine("{0} infligge {1} di danni a {2}", nemico.nome, attacco, mainPg.nome);
                                Console.WriteLine("Energia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg.nome, mainPg.energiaVitale, boss.nome, boss.energiaVitale);

                            }
                            /// attacco del nemico
                            int attaccoNemico = at.Next(2, 10);
                            mainPg.energiaVitale -= attaccoNemico;
                            Console.WriteLine("{0} infligge {1} di danni a {2}", boss.nome, attaccoNemico, mainPg.nome);
                            Console.WriteLine("Energia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg.nome, mainPg.energiaVitale, boss.nome, boss.energiaVitale);

                            if (mainPg.energiaVitale <= 0)
                            {
                                bacchetta(boss);
                                sconfitta();
                                break;
                            }
                            Console.WriteLine("Premi per continuare...");
                            Console.ReadKey();
                            Console.WriteLine("\nTuo turno: ");
                            ////attacco del main
                            foreach (Buoni alleato in alleati)
                            {
                                ///attacco dei alleati
                                int attacco = at.Next(1, 3);
                                boss.energiaVitale -= attacco;
                                Console.WriteLine("{0} infligge {1} di danni a {2}", alleato.nome, attacco, boss.nome);
                                Console.WriteLine("Energia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg.nome, mainPg.energiaVitale, boss.nome, boss.energiaVitale);

                            }
                            /// attacco tuo
                            int attaccoPrincipale = at.Next(2, 10);
                            boss.energiaVitale -= attaccoPrincipale;
                            Console.WriteLine("{0} infligge {1} di danni a {2}", mainPg.nome, attaccoPrincipale, boss.nome);
                            Console.WriteLine("Energia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg.nome, mainPg.energiaVitale, boss.nome, boss.energiaVitale);

                            if (boss.energiaVitale <= 0)
                            {
                                bacchetta2(mainPg);
                                vittoria();
                                break;
                            }
                        }
                        Console.WriteLine("Premi per passare al prossimo round...");
                        Console.ReadKey();


                    }

                    break;
                case "Male":
                    Random r1 = new Random();
                    Console.WriteLine("Ti sei unito alle forze del Male! \nOra dovrai seguire gli ordini di ");
                    ConsoleColor colorePredefinito = Console.ForegroundColor;
                    Console.ForegroundColor = ConsoleColor.DarkGreen;
                    Console.Write("V");
                    Thread.Sleep(200);
                    Console.Write("\to");
                    Thread.Sleep(200);
                    Console.Write("\tl");
                    Thread.Sleep(200);
                    Console.Write("\td");
                    Thread.Sleep(200);
                    Console.Write("\te");
                    Thread.Sleep(200);
                    Console.Write("\tm");
                    Thread.Sleep(200);
                    Console.Write("\to");
                    Thread.Sleep(200);
                    Console.Write("\tr");
                    Thread.Sleep(200);
                    Console.Write("\tt");
                    Thread.Sleep(200);
                    Console.ForegroundColor = colorePredefinito;
                    Thread.Sleep(200);
                    Console.WriteLine("\nPrima di tutto , come ti chiami ? ");
                    string nome2 = Console.ReadLine();
                    MagoMaster mainPg2 = new MagoMaster(nome2, 7, 20);  ////main
                    
                    Malvagi[] alleati2 = new Malvagi[2]
                   {
                        new Malvagi("mago mangiamorte","Bellatrix Lestrange", r1.Next(1,10), 10),
                        new Malvagi("mago mangiamorte", "Codaliscia ",r1.Next(1,10), 10)
                   };

                    Buoni[] nemici2 = new Buoni[4]
                   {  
                        new Buoni("tassorosso","Cedric Diggory", r1.Next(1,10), 5 ),
                        new Buoni("corvonero", "Luna Lovegood",r1.Next(1,10), 6),
                        new Buoni("grifondoro","Neville Paciock", r1.Next(1,10), 7 ),
                        new Buoni("grifondoro", "Ron Weasley",r1.Next(1,10), 8),
                   };
                    //////creazione del boss
                    MagoMaster boss2 = new MagoMaster("Harry Potter", 6 , 20); ///boss
                    Console.WriteLine("\nBene {0}!\nEcco la lista dei tuoi alleati: ", mainPg2.nome);
                    Thread.Sleep(200);
                    foreach (Malvagi buono in alleati2)
                    {
                        Console.WriteLine("\nAlleato: \nnome: {0}\ntipologia: {1}\nesperienza di combattimento: {2}\nforza di combattimento: {3}", buono.nome, buono.casataA, buono.esperienzaCombattimento, buono.forza1);
                        Thread.Sleep(300);
                    }
                    Thread.Sleep(500);
                    Console.WriteLine("\nPremi un tasto per continuare...");
                    Console.ReadKey();
                    Console.WriteLine("\nEcco la lista dei tuoi nemici: ");
                    Thread.Sleep(500);
                    foreach (Buoni cattivi in nemici2)
                    {
                        Console.WriteLine("\nNemico: \nnome: {0}\ncasata: {1}\nesperienza di combattimento: {2}\nforza di combattimento: {3}", cattivi.nome, cattivi.casataA, cattivi.esperienzaCombattimento, cattivi.forza1);
                        Thread.Sleep(300);
                    }
                    Thread.Sleep(300);
                    Console.WriteLine("\nPremi un tasto per continuare...\n");
                    Console.ReadKey();
                    inizio();
                    ConsoleColor colorePredefinito1 = Console.ForegroundColor;
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.Write(" H");
                    Thread.Sleep(100);
                    Console.Write("a");
                    Thread.Sleep(100);
                    Console.Write("r");
                    Thread.Sleep(100);
                    Console.Write("r");
                    Thread.Sleep(100);
                    Console.Write("y");
                    Thread.Sleep(100);
                    Console.Write(" ");
                    Thread.Sleep(100);
                    Console.Write("P");
                    Thread.Sleep(100);
                    Console.Write("o");
                    Thread.Sleep(100);
                    Console.Write("t");
                    Thread.Sleep(100);
                    Console.Write("t");
                    Thread.Sleep(100);
                    Console.Write("e");
                    Thread.Sleep(100);
                    Console.Write("r");
                    Thread.Sleep(100);
                    
                    Console.ForegroundColor = colorePredefinito1;

                    Console.WriteLine("\nPremi un tasto per cominciare a combattere contro i Maghi di Hogwarts...\n");
                    Console.ReadKey();


                    int forzatotPg=0;
                    foreach (Malvagi alleato in alleati2 )
                    {
                        forzatotPg = mainPg2.forza + alleato.forza1;
                    }
                    int forzatotN=0;
                    foreach (Buoni nemico in nemici2)
                    {
                        forzatotPg = mainPg2.forza + nemico.forza1;
                    }
                    if (forzatotPg > forzatotN)
                    {
                        mainPg2.energiaVitale += 10;
                        Console.WriteLine("La tua forza combattiva totale è maggiore di quella dei tuoi nemici\nOttieni +10 energia vitale ");
                    }
                    if(forzatotPg < forzatotN)
                    {
                        boss2.energiaVitale += 8;
                        Console.WriteLine("La tua forza combattiva totale è minore di quella dei tuoi nemici\nIl nemico ottiene +8 energia vitale ");
                    }
                    if (forzatotPg == forzatotN)
                    {
                        boss2.energiaVitale += 5;
                        mainPg2.energiaVitale += 5;
                        Console.WriteLine("La tua forza combattiva totale è uguale a quella dei tuoi nemici\nEntrambi ottenete +5 energia vitale ");
                    }
                    Random at1 = new Random();
                    while(mainPg2.energiaVitale>0 && boss2.energiaVitale > 0)
                    {
                        Console.WriteLine("\nEnergia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg2.nome, mainPg2.energiaVitale, boss2.nome, boss2.energiaVitale);
                        int calcolaTurno = at1.Next(1, 3);
                        //// il turno è calcolato in base alla forza totale dei due personaggi(master+ alleati)
                        if (calcolaTurno==1)
                        {
                            lancioDadi();
                            Console.WriteLine("\nTuo turno: ");
                            foreach (Malvagi alleato in alleati2)
                            {
                                ///attacco dei tuoi alleati
                                int attacco = at1.Next(1, 5);
                                boss2.energiaVitale-=attacco;
                                Console.WriteLine("{0} infligge {1} di danni a {2}", alleato.nome, attacco, boss2.nome);
                                Console.WriteLine("Energia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}",mainPg2.nome, mainPg2.energiaVitale, boss2.nome, boss2.energiaVitale);
                            }
                            ///tuo attacco
                            int attaccoPrincipale=at1.Next(2, 10);
                            boss2.energiaVitale -= attaccoPrincipale;
                            Console.WriteLine("{0} infligge {1} di danni a {2}", mainPg2.nome, attaccoPrincipale, boss2.nome);
                            Console.WriteLine("Energia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg2.nome, mainPg2.energiaVitale, boss2.nome, boss2.energiaVitale);
                            if (boss2.energiaVitale <= 0)
                            {
                                bacchetta(mainPg2);
                                vittoria();
                                break;
                            }
                            Console.WriteLine("Premi per continuare...");
                            Console.ReadKey();
                            Console.WriteLine("\nTurno del nemico: ");
                            foreach (Buoni nemico in nemici2)
                            {
                                ///attacco dei alleati del nemico
                                int attacco = at1.Next(1, 3);
                                mainPg2.energiaVitale -= attacco;
                                Console.WriteLine("{0} infligge {1} di danni a {2}", nemico.nome, attacco, mainPg2.nome);
                                Console.WriteLine("Energia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg2.nome, mainPg2.energiaVitale, boss2.nome, boss2.energiaVitale);

                            }
                            /// attacco del nemico
                            
                            int attaccoNemico = at1.Next(2, 10);
                            mainPg2.energiaVitale -= attaccoNemico;
                            Console.WriteLine("{0} infligge {1} di danni a {2}", boss2.nome, attaccoNemico, mainPg2.nome);
                            Console.WriteLine("Energia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg2.nome, mainPg2.energiaVitale, boss2.nome, boss2.energiaVitale);

                            if (mainPg2.energiaVitale <= 0)
                            {
                                bacchetta2(boss2);
                                sconfitta();
                                break;
                            }
                        }
                        if(calcolaTurno==2)
                        {
                            lancioDadi();                           
                            Console.WriteLine("\nTurno del nemico: ");
                            foreach (Buoni nemico in nemici2)
                            {
                                ///attacco dei alleati del nemico
                                int attacco = at1.Next(1, 3);
                                mainPg2.energiaVitale -= attacco;
                                Console.WriteLine("{0} infligge {1} di danni a {2}", nemico.nome, attacco, mainPg2.nome);
                                Console.WriteLine("Energia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg2.nome, mainPg2.energiaVitale, boss2.nome, boss2.energiaVitale);

                            }
                            /// attacco del nemico
                            int attaccoNemico = at1.Next(2, 10);
                            mainPg2.energiaVitale -= attaccoNemico;
                            Console.WriteLine("{0} infligge {1} di danni a {2}", boss2.nome, attaccoNemico, mainPg2.nome);
                            Console.WriteLine("Energia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg2.nome, mainPg2.energiaVitale, boss2.nome, boss2.energiaVitale);

                            if (mainPg2.energiaVitale <= 0)
                            {
                                bacchetta2(boss2);
                                sconfitta();
                                break;
                            }
                            Console.WriteLine("Premi per continuare...");
                            Console.ReadKey();
                            Console.WriteLine("\nTuo turno: ");
                            ////attacco del main
                            foreach (Malvagi alleato in alleati2)
                            {
                                ///attacco dei alleati
                                int attacco = at1.Next(1, 3);
                                boss2.energiaVitale -= attacco;
                                Console.WriteLine("{0} infligge {1} di danni a {2}", alleato.nome, attacco, boss2.nome);
                                Console.WriteLine("Energia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg2.nome, mainPg2.energiaVitale, boss2.nome, boss2.energiaVitale);

                            }
                            /// attacco tuo
                            int attaccoPrincipale = at1.Next(2, 10);
                            boss2.energiaVitale -= attaccoPrincipale;
                            Console.WriteLine("{0} infligge {1} di danni a {2}", mainPg2.nome, attaccoPrincipale, boss2.nome);
                            Console.WriteLine("Energia vitale di {0} : {1}  ||   Energia vitale di {2} : {3}", mainPg2.nome, mainPg2.energiaVitale, boss2.nome, boss2.energiaVitale);

                            if (boss2.energiaVitale <= 0)
                            {
                                bacchetta(mainPg2);
                                vittoria();
                                break;
                            }
                        }
                        Console.WriteLine("Premi per passare al prossimo round...");
                        Console.ReadKey();
                        
                        
                    }

                    /////fine
                    break;

            }
            //// ogni volta che elimina un nemico si aggiunge 1 punto di esperienza
            //// l esperienza base è random tra 1-10
        }
        public void lancioDadi()
        {
            Console.Write("l");
            Thread.Sleep(10);
            Console.Write("a");
            Thread.Sleep(10);
            Console.Write("n");
            Thread.Sleep(10);
            Console.Write("c");
            Thread.Sleep(10);
            Console.Write("i");
            Thread.Sleep(10);
            Console.Write("o");
            Thread.Sleep(10);
            Console.Write(" ");
            Thread.Sleep(10);
            Console.Write("d");
            Thread.Sleep(10);
            Console.Write("e");
            Thread.Sleep(10);
            Console.Write("i");
            Thread.Sleep(10);
            Console.Write(" ");
            Thread.Sleep(10);
            Console.Write("d");
            Thread.Sleep(10);
            Console.Write("a");
            Thread.Sleep(10);
            Console.Write("d");
            Thread.Sleep(10);
            Console.Write("i");
            Thread.Sleep(10);
            Console.Write(" ");
            Thread.Sleep(10);

            Console.Write(".");
            Thread.Sleep(300);
            Console.Write(".");
            Thread.Sleep(300);
            Console.Write(".");
            Thread.Sleep(300);
        }
        public void inizio()
        {
            Console.Write("\nI");
            Thread.Sleep(100);
            Console.Write("l");
            Thread.Sleep(100);
            Console.Write(" ");
            Thread.Sleep(100);
            Console.Write("t");
            Thread.Sleep(100);
            Console.Write("u");
            Thread.Sleep(100);
            Console.Write("o");
            Thread.Sleep(100);
            Console.Write(" ");
            Thread.Sleep(100);
            Console.Write("o");
            Thread.Sleep(100);
            Console.Write("b");
            Thread.Sleep(100);
            Console.Write("b");
            Thread.Sleep(100);
            Console.Write("i");
            Thread.Sleep(100);
            Console.Write("e");
            Thread.Sleep(100);
            Console.Write("t");
            Thread.Sleep(100);
            Console.Write("t");
            Thread.Sleep(100);
            Console.Write("i");
            Thread.Sleep(100);
            Console.Write("v");
            Thread.Sleep(100);
            Console.Write("o");
            Thread.Sleep(100);
            Console.Write(" ");
            Thread.Sleep(100);
            Console.Write("è");
            Thread.Sleep(100);
            Console.Write(" ");
            Thread.Sleep(100);
            Console.Write("s");
            Thread.Sleep(100);
            Console.Write("c");
            Thread.Sleep(100);
            Console.Write("o");
            Thread.Sleep(100);
            Console.Write("n");
            Thread.Sleep(100);
            Console.Write("f");
            Thread.Sleep(100);
            Console.Write("i");
            Thread.Sleep(100);
            Console.Write("g");
            Thread.Sleep(100);
            Console.Write("g");
            Thread.Sleep(100);
            Console.Write("e");
            Thread.Sleep(100);
            Console.Write("r");
            Thread.Sleep(100);
            Console.Write("e");
            Thread.Sleep(100);
            Console.Write(" ");
            Thread.Sleep(100);
            
        }
        public void sconfitta()
        {
            ConsoleColor colorePredefinito = Console.ForegroundColor;

            // Imposta il colore del testo in rosso e stampa le stringhe
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("F");
            Thread.Sleep(100);
            Console.Write("\tA");
            Thread.Sleep(100);
            Console.Write("\tT");
            Thread.Sleep(100);
            Console.Write("\tA");
            Thread.Sleep(100);
            Console.Write("\tL");
            Thread.Sleep(100);
            Console.Write("\tI");
            Thread.Sleep(100);
            Console.Write("\tT");
            Thread.Sleep(100);
            Console.Write("\tY");
            Thread.Sleep(100);
            Console.ForegroundColor = colorePredefinito;
            // Console.Write("\n\nHAI PERSO!");


        }
        public void vittoria()
        {
            ConsoleColor colorePredefinito = Console.ForegroundColor;

            // Imposta il colore del testo in rosso e stampa le stringhe
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write("V");
            Thread.Sleep(100);
            Console.Write("\tI");
            Thread.Sleep(100);
            Console.Write("\tT");
            Thread.Sleep(100);
            Console.Write("\tT");
            Thread.Sleep(100);
            Console.Write("\tO");
            Thread.Sleep(100);
            Console.Write("\tR");
            Thread.Sleep(100);
            Console.Write("\tI");
            Thread.Sleep(100);
            Console.Write("\tA");
            Thread.Sleep(100);
            Console.ForegroundColor = colorePredefinito;
        }
        private bool CiSonoAvversariVivi(Personaggio[] array)
        {
            foreach (Personaggio nemico in array)
            {
                if (nemico.hp > 0)
                {
                    return true;
                }
            }
            return false;
        }
        public void Scontro(MagoMaster pg, Personaggio avversario)
        {
            ConsoleColor colorePredefinito3 = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine($"{pg.nome} HP: {pg.hp} vs {avversario.nome} HP : {avversario.hp}");
            Console.ForegroundColor = colorePredefinito3;


            // Attacco del main
            int dannoEroe = pg.CalcolaForzaCombattimento(10,"");
            avversario.hp -= dannoEroe;

            Console.WriteLine($"{pg.nome} attacca {avversario.nome} e infligge {dannoEroe} di danno.");

            // Verifica se il nemico è stato sconfitto dopo l'attacco dell'eroe
            if (avversario.hp <= 0)
            {
                Console.WriteLine($"{pg.nome} HP: {pg.hp} | {avversario.nome} HP: {0}");
                ConsoleColor colorePredefinito2 = Console.ForegroundColor;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"{avversario.nome}--- eliminato ");
                Console.ForegroundColor = colorePredefinito2;

                return;
            }


            // Attacco dell'avversario
            int dannoAvversario = avversario.CalcolaForzaCombattimento(5,"");
            pg.hp -= dannoAvversario;



            Console.WriteLine($"{avversario.nome} attacca {pg.nome}  e infligge {dannoAvversario} di danno.");
            if (pg.hp <= 0)
            {
                Console.WriteLine($"{pg.nome} HP: 0 | {avversario.nome} HP: {avversario.hp}");
                ConsoleColor colorePredefinito2 = Console.ForegroundColor;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"{pg.nome} è stato eliminato ");
                Console.ForegroundColor = colorePredefinito2;

                return;
            }

            Console.WriteLine($"{pg.nome} HP: {pg.hp} | {avversario.nome} HP: {avversario.hp}");
        }
        public void bacchetta(MagoMaster pg)
        {
            Console.WriteLine("{0} utilizza la maledizione mortale Avada Kedavra!!! ", pg.nome);
            ConsoleColor colorePrede1 = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write(">");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write(">");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write(">\n");
            Thread.Sleep(10);

            Console.ForegroundColor = colorePrede1;
        }
        public void bacchetta2(MagoMaster pg)
        {
            Console.WriteLine("{0} utilizza l'incantesimo di disarmo Expelliarmus!!! ", pg.nome);
            ConsoleColor colorePrede1 = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write(">");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write(">");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write("-");
            Thread.Sleep(10);
            Console.Write(">\n");
            Thread.Sleep(10);

            Console.ForegroundColor = colorePrede1;
        }


    }
}