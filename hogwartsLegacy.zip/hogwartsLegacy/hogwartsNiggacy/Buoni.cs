﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hogwartsNiggacy
{
     class Buoni: Personaggio
    {
        public string casataA { get; set; }
        public int forza1 { get; set; }
        public Buoni(string casata, string nome, int esperienzaCombattimento, int hp) : base(nome, esperienzaCombattimento, hp)
        {
            casataA = casata;
            forza1 = CalcolaForzaCombattimento(esperienzaCombattimento, casataA);
        }
        public override int CalcolaForzaCombattimento(int esp, string casataAppartenenza)
        {
            int forzaBase = 0;

            switch (casataAppartenenza)
            {
                case "grifondoro":
                    forzaBase = 10;
                    return forzaBase + 5 * esperienzaCombattimento;

                case "serpeverde":
                    forzaBase = 10;
                    return forzaBase + 6 * esperienzaCombattimento;

                case "tassorosso":
                    forzaBase = 9;
                    return forzaBase + 5 * esperienzaCombattimento;

                case "corvonero":
                    forzaBase = 10;
                    return forzaBase + 3 * esperienzaCombattimento;

                case "maestro":
                    forzaBase = 12;
                    return forzaBase + 7 * esperienzaCombattimento;
                default:
                    // default fa ritornare 0 se la casata inserita non esiste
                    return forzaBase;
            }
        }
    }
}
