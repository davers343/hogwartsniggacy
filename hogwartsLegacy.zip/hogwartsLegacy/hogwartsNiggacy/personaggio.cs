﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hogwartsNiggacy
{
      abstract class  Personaggio
    {
        public string nome { get; set; }
        public int hp { get; set; }
        public int esperienzaCombattimento { get; set; }
        //public int forzaCombattimento { get; set; }

        public Personaggio(string nome, int esperienzaCombat, int hp)
        {
            this.nome = nome;
            this.esperienzaCombattimento = esperienzaCombat;
            this.hp = hp;
            //forzaCombattimento= forza;
        }
        public abstract int CalcolaForzaCombattimento(int esp, string casataAppartenenza);
       
    }
}
